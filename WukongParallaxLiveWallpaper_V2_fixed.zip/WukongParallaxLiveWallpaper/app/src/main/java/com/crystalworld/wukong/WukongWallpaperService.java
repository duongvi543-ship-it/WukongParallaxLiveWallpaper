package com.crystalworld.wukong;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.service.wallpaper.WallpaperService;
import android.view.MotionEvent;
import android.view.SurfaceHolder;

public class WukongWallpaperService extends WallpaperService {

    @Override
    public Engine onCreateEngine() {
        return new WukongEngine();
    }

    private class WukongEngine extends Engine {
        private Bitmap base, wukong, warrior, atmosphere;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Handler handler = new Handler(Looper.getMainLooper());

        private int width, height;
        private boolean visible = false;
        private boolean touching = false;
        private float downX;
        private float touchTarget = 0f;
        private float scrollTarget = 0f;
        private float parallax = 0f;
        private long startTime;

        // Layer travel: back -> front.
        private final float[] layerStrength = {0.05f, 0.22f, 0.38f, 0.58f};

        private final Runnable drawRunnable = new Runnable() {
            @Override public void run() {
                if (visible) {
                    drawFrame();
                    handler.postDelayed(this, 33L); // ~30 FPS, battery-conscious.
                }
            }
        };

        @Override
        public void onCreate(SurfaceHolder holder) {
            super.onCreate(holder);
            setTouchEventsEnabled(true);
            setOffsetNotificationsEnabled(true);
            startTime = System.currentTimeMillis();
            base = BitmapFactory.decodeResource(getResources(), R.drawable.layer1_3_base);
            wukong = BitmapFactory.decodeResource(getResources(), R.drawable.layer4_wukong);
            warrior = BitmapFactory.decodeResource(getResources(), R.drawable.layer5_warrior);
            atmosphere = BitmapFactory.decodeResource(getResources(), R.drawable.layer5_foreground_atmosphere);
        }

        @Override
        public void onVisibilityChanged(boolean isVisible) {
            visible = isVisible;
            if (visible) {
                handler.removeCallbacks(drawRunnable);
                handler.post(drawRunnable);
            } else {
                handler.removeCallbacks(drawRunnable);
            }
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int w, int h) {
            super.onSurfaceChanged(holder, format, w, h);
            width = w;
            height = h;
            drawFrame();
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            visible = false;
            handler.removeCallbacks(drawRunnable);
            super.onSurfaceDestroyed(holder);
        }

        @Override
        public void onDestroy() {
            visible = false;
            handler.removeCallbacks(drawRunnable);
            if (base != null) base.recycle();
            if (wukong != null) wukong.recycle();
            if (warrior != null) warrior.recycle();
            if (atmosphere != null) atmosphere.recycle();
            super.onDestroy();
        }

        @Override
        public void onOffsetsChanged(float xOffset, float yOffset,
                                     float xOffsetStep, float yOffsetStep,
                                     int xPixelOffset, int yPixelOffset) {
            // Launcher page scrolling: xOffset is normalized to the wallpaper container.
            scrollTarget = clamp((xOffset - 0.5f) * 2f, -1f, 1f);
            if (!touching) touchTarget = scrollTarget;
        }

        @Override
        public void onTouchEvent(MotionEvent event) {
            float x = event.getX();
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    touching = true;
                    downX = x;
                    touchTarget = parallax;
                    break;
                case MotionEvent.ACTION_MOVE:
                    float dx = x - downX;
                    float normalized = dx / Math.max(1f, width);
                    touchTarget = clamp(parallax + normalized * 1.35f, -1f, 1f);
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    touching = false;
                    touchTarget = scrollTarget;
                    break;
            }
        }

        private void drawFrame() {
            SurfaceHolder holder = getSurfaceHolder();
            Canvas canvas = null;
            try {
                canvas = holder.lockCanvas();
                if (canvas == null) return;

                canvas.drawColor(0xFF060711);

                // Smooth spring toward the current interaction target.
                parallax += (touchTarget - parallax) * 0.18f;

                float t = (System.currentTimeMillis() - startTime) / 1000f;
                float breathe = (float)Math.sin(t * 1.15f);
                float drift = (float)Math.sin(t * 0.55f);

                // The source art is 9:16. Fit to screen height and crop only excess width.
                float scale = Math.max(width / (float) base.getWidth(),
                                       height / (float) base.getHeight());
                float dw = base.getWidth() * scale;
                float dh = base.getHeight() * scale;
                float baseLeft = (width - dw) / 2f;
                float baseTop = (height - dh) / 2f;
                float horizontalRoom = Math.max(0f, (dw - width) / 2f);

                drawLayer(canvas, base, baseLeft + parallax * horizontalRoom * layerStrength[0],
                        baseTop, dw, dh, 255);

                // Wukong: strong but controlled motion + very subtle vertical breathing.
                float wx = baseLeft + parallax * horizontalRoom * layerStrength[1];
                float wy = baseTop + breathe * height * 0.0035f;
                drawLayer(canvas, wukong, wx, wy, dw, dh, 255);

                // Warrior: foreground character moves more than Wukong.
                float ax = baseLeft + parallax * horizontalRoom * layerStrength[2];
                float ay = baseTop + drift * height * 0.0045f;
                drawLayer(canvas, warrior, ax, ay, dw, dh, 255);

                // Foreground atmosphere/petals: strongest parallax, low-opacity breathing.
                float fx = baseLeft + parallax * horizontalRoom * layerStrength[3];
                float fy = baseTop + drift * height * 0.006f;
                int alpha = 238 + (int)(10f * breathe);
                drawLayer(canvas, atmosphere, fx, fy, dw, dh, alpha);
            } finally {
                if (canvas != null) holder.unlockCanvasAndPost(canvas);
            }
        }

        private void drawLayer(Canvas c, Bitmap bitmap, float left, float top,
                               float w, float h, int alpha) {
            if (bitmap == null || bitmap.isRecycled()) return;
            paint.setAlpha(clamp(alpha, 0, 255));
            RectF dst = new RectF(left, top, left + w, top + h);
            c.drawBitmap(bitmap, null, dst, paint);
        }

        private float clamp(float v, float min, float max) {
            return Math.max(min, Math.min(max, v));
        }

        private int clamp(int v, int min, int max) {
            return Math.max(min, Math.min(max, v));
        }
    }
}
