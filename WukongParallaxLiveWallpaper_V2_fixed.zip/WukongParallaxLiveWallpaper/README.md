# Wukong Parallax Live Wallpaper — V1

Đây là prototype Live Wallpaper Android dùng `WallpaperService.Engine`.

## Đã có
- 4 asset layer từ bộ Wukong hiện tại.
- Parallax nhiều tốc độ: nền → Wukong → chiến binh → foreground.
- Nhận `onOffsetsChanged()` để phản ứng với thao tác chuyển trang Home nếu launcher gửi wallpaper offsets.
- Nhận raw touch bằng `onTouchEvent()` khi hệ thống/launcher cho phép.
- Spring/easing khi thả tay.
- Chuyển động idle nhẹ ~30 FPS: breathing/drift.
- Nút mở thẳng màn hình đặt Live Wallpaper.

## Build
1. Mở thư mục này bằng Android Studio mới.
2. Chờ Gradle Sync.
3. Build > Build APK(s).
4. Cài APK lên Xiaomi 15T.
5. Mở app → **ĐẶT HÌNH NỀN ĐỘNG** → chọn Home screen (và Lock screen nếu muốn).

## Lưu ý Xiaomi/HyperOS
Android cung cấp cả `onOffsetsChanged()` và `onTouchEvent()` cho Live Wallpaper. Launcher quyết định những sự kiện nào được chuyển tới wallpaper. Vì vậy V1 ưu tiên `onOffsetsChanged()` cho thao tác vuốt giữa các trang Home và có raw-touch fallback.

Nếu Xiaomi 15T vẫn không truyền offset/touch theo cách mong muốn, V2 có thể tinh chỉnh riêng cho HyperOS (độ mạnh parallax, hướng, giới hạn chuyển động, FPS, và animation idle).

## Nguồn kỹ thuật
Android `WallpaperService` / `WallpaperService.Engine`:
https://developer.android.com/reference/kotlin/android/service/wallpaper/WallpaperService
https://developer.android.com/reference/android/service/wallpaper/WallpaperService.Engine
